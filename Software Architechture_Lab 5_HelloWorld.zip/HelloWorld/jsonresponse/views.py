from django.shortcuts import render
from django.http import JsonResponse

def send_json(request):

    data = [{'Message': 'Hello World'}]

    return JsonResponse(data, safe=False)

# Create your views here.
