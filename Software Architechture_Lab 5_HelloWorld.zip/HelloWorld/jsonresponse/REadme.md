#This is a simple hello world using Json
To run the app we use the following command in terminal
Step 1
Navigate to the project directory
Cd HelloWorld
Step 2: Run the following command in terminal
python manage.py runserver
 Step 3:
The above command will create a server link at 
http://127.0.0.1:8000
 Step 4
when you open the the link, to acccess my response you need to add the following in the created weblink
http://127.0.0.1:8000/sendjson/

The hello message is returned.
